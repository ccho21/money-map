// 📁 src/stats/dto/category/group-summary.dto.ts
import { BaseListSummaryResponseDTO } from '../base/base-list-summary-response.dto';
import { CategoryStatsGroupDTO } from './group-item.dto';

export type CategoryGroupSummaryDTO =
  BaseListSummaryResponseDTO<CategoryStatsGroupDTO>;
