// 📁 src/stats/dto/category/group-item.dto.ts
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsEnum, IsString } from 'class-validator';
import { CategoryType } from '@prisma/client';
import { BaseStatsItemDTO } from '../base/base-stats-item.dto';

export class CategoryStatsGroupItemDTO extends BaseStatsItemDTO {}

export class CategoryStatsGroupDTO {
  @ApiProperty()
  @IsString()
  id: string;

  @ApiProperty()
  @IsEnum(CategoryType)
  type: CategoryType;

  @ApiProperty()
  @IsString()
  name: string;

  @ApiProperty()
  @IsString()
  icon: string;

  @ApiProperty()
  @IsString()
  color: string;

  @ApiProperty({ type: [CategoryStatsGroupItemDTO] })
  @IsArray()
  items: CategoryStatsGroupItemDTO[];
}
