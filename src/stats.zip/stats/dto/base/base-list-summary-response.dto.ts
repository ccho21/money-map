// 📁 src/stats/dto/base/base-list-summary-response.dto.ts
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNumber, IsOptional } from 'class-validator';

export class BaseListSummaryResponseDTO<T> {
  @ApiProperty({ type: [Object] })
  @IsArray()
  data: T[];

  @ApiProperty()
  @IsNumber()
  total: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  rate?: number;
}
