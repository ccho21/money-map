// 📁 src/stats/dto/budget/group-item.dto.ts
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsEnum, IsString } from 'class-validator';
import { CategoryType } from '@prisma/client';
import { BaseStatsItemDTO } from '../base/base-stats-item.dto';

export class BudgetStatsGroupItemDTO extends BaseStatsItemDTO {}

export class BudgetStatsGroupDTO {
  @ApiProperty()
  @IsString()
  id: string;

  @ApiProperty()
  @IsEnum(CategoryType)
  type: CategoryType;

  @ApiProperty()
  @IsString()
  name: string;

  @ApiProperty()
  @IsString()
  icon: string;

  @ApiProperty()
  @IsString()
  color: string;

  @ApiProperty()
  totalBudget: number;

  @ApiProperty()
  totalUsed: number;

  @ApiProperty()
  remaining: number;

  @ApiProperty()
  rate: number;

  @ApiProperty()
  hasBudget: boolean;

  @ApiProperty()
  totalRemaining: number; // ✅ 추가

  @ApiProperty()
  isOver: boolean; // ✅ 추가

  @ApiProperty({ type: [BudgetStatsGroupItemDTO] })
  @IsArray()
  items: BudgetStatsGroupItemDTO[];
}
