// 📁 src/stats/dto/budget/group-summary.dto.ts
import { BaseListSummaryResponseDTO } from '../base/base-list-summary-response.dto';
import { BudgetStatsGroupDTO } from './group-item.dto';

export type BudgetGroupSummaryDTO =
  BaseListSummaryResponseDTO<BudgetStatsGroupDTO>;
