// 📁 src/stats/dto/note/group-summary.dto.ts
import { BaseListSummaryResponseDTO } from '../base/base-list-summary-response.dto';
import { NoteStatsGroupDTO } from './group-item.dto';

export type NoteGroupSummaryDTO = BaseListSummaryResponseDTO<NoteStatsGroupDTO>;
