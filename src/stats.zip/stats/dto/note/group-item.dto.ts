// 📁 src/stats/dto/note/group-item.dto.ts
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsEnum, IsString } from 'class-validator';
import { CategoryType } from '@prisma/client';
import { BaseStatsItemDTO } from '../base/base-stats-item.dto';

export class NoteStatsGroupItemDTO extends BaseStatsItemDTO {}

export class NoteStatsGroupDTO {
  @ApiProperty()
  @IsString()
  note: string;

  @ApiProperty()
  @IsEnum(CategoryType)
  type: CategoryType;

  @ApiProperty({ type: [NoteStatsGroupItemDTO] })
  @IsArray()
  items: NoteStatsGroupItemDTO[];
}
