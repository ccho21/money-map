export type UserPayload = {
  id: string;
  email: string;
  timezone?: string;
};
