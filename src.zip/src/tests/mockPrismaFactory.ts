import { PrismaService } from '@/prisma/prisma.service';
import { jest } from '@jest/globals';

/**
 * ✅ 최소 테스트 실행을 위한 mockPrismaFactory
 * 필요한 model(delegate)만 jest.fn()으로 초기화됨
 */
export const mockPrismaFactory = (): jest.Mocked<PrismaService> => {
  return {
    user: {
      findUnique: jest.fn(),
      update: jest.fn(),
    },
    account: {
      findUnique: jest.fn(),
      update: jest.fn(),
      create: jest.fn(),
      findMany: jest.fn(),
    },
    transaction: {
      findUnique: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      deleteMany: jest.fn(),
      groupBy: jest.fn(),
    },
    category: {
      findUnique: jest.fn(),
      update: jest.fn(),
    },
    $transaction: jest.fn(),
    $connect: jest.fn(),
    $disconnect: jest.fn(),
  } as unknown as jest.Mocked<PrismaService>;
};
