-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "color" TEXT;
