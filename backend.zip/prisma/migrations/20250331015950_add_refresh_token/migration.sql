-- AlterTable
ALTER TABLE "User" ADD COLUMN     "hashedRefreshToken" TEXT;
