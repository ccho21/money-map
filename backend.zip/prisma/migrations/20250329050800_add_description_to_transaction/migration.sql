-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "description" TEXT;
