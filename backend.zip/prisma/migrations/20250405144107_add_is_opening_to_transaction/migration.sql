-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "isOpening" BOOLEAN NOT NULL DEFAULT false;
