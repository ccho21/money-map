-- AlterTable
ALTER TABLE "Account" ADD COLUMN     "description" TEXT;
