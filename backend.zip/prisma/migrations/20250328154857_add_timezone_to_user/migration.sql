-- AlterTable
ALTER TABLE "User" ADD COLUMN     "timezone" TEXT;
