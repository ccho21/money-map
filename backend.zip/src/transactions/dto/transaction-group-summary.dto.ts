import { BaseListSummaryResponseDTO } from '@/common/dto/base-list-summary-response.dto';
import { TransactionGroupItemDTO } from './transaction-group-item.dto';

export class TransactionGroupSummaryDTO extends BaseListSummaryResponseDTO<TransactionGroupItemDTO> {}
